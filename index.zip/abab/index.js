'use strict';

var atob = require('./lib/atob');
var btoa = require('./lib/btoa');

module.exports = {
  atob: atob,
  btoa: btoa
};
